#ifndef USER_INPUT_H
#define USER_INPUT_H

char *get_user_input(char *prompt);

#endif